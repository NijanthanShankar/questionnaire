<?php
/**
 * CleanIndex Portal - Payment Handler
 * COMPLETE FILE WITH ALL FIXES APPLIED
 * FIX #4: Better validation for payment methods
 * 
 * FILE LOCATION: wp-content/plugins/cleanindex-portal/includes/payment-handler.php
 */

if (!defined('ABSPATH')) exit;

/**
 * Initialize WooCommerce Payment Gateway Support
 */
add_action('init', 'cip_init_woo_payment');

function cip_init_woo_payment() {
    if (!class_exists('WooCommerce')) {
        return;
    }
    
    // Make sure products exist
    cip_ensure_products_exist();
}

/**
 * Ensure WooCommerce products exist for each plan
 */
function cip_ensure_products_exist() {
    if (!class_exists('WooCommerce')) {
        return;
    }
    
    $pricing_plans = get_option('cip_pricing_plans', []);
    
    foreach ($pricing_plans as $index => $plan) {
        $product_id = get_option('cip_woo_product_' . $index);
        
        // Check if product exists
        if (!$product_id || get_post_status($product_id) !== 'publish') {
            // Create product
            $product = new WC_Product_Simple();
            $product->set_name('CleanIndex ' . $plan['name'] . ' Plan');
            $product->set_regular_price($plan['price']);
            $product->set_description('ESG Certification - ' . $plan['name'] . ' Plan');
            $product->set_virtual(true);
            $product->set_sold_individually(true);
            $product->set_catalog_visibility('hidden');
            
            // Save meta
            $product->update_meta_data('_cip_plan_index', $index);
            $product->update_meta_data('_cip_plan_name', $plan['name']);
            
            $product_id = $product->save();
            update_option('cip_woo_product_' . $index, $product_id);
        }
    }
}

/**
 * Update WooCommerce products when plans change
 */
function cip_update_woocommerce_products($old_plans, $new_plans) {
    if (!class_exists('WooCommerce')) {
        return;
    }
    
    foreach ($new_plans as $index => $plan) {
        $product_id = get_option('cip_woo_product_' . $index);
        
        if ($product_id) {
            $product = wc_get_product($product_id);
            if ($product) {
                $product->set_name('CleanIndex ' . $plan['name'] . ' Plan');
                $product->set_regular_price($plan['price']);
                $product->set_description('ESG Certification - ' . $plan['name'] . ' Plan');
                $product->update_meta_data('_cip_plan_name', $plan['name']);
                $product->save();
            }
        } else {
            // Create new product
            $product = new WC_Product_Simple();
            $product->set_name('CleanIndex ' . $plan['name'] . ' Plan');
            $product->set_regular_price($plan['price']);
            $product->set_description('ESG Certification - ' . $plan['name'] . ' Plan');
            $product->set_virtual(true);
            $product->set_sold_individually(true);
            $product->set_catalog_visibility('hidden');
            $product->update_meta_data('_cip_plan_index', $index);
            $product->update_meta_data('_cip_plan_name', $plan['name']);
            
            $product_id = $product->save();
            update_option('cip_woo_product_' . $index, $product_id);
        }
    }
}

/**
 * AJAX: Get Available Payment Methods
 */
add_action('wp_ajax_cip_get_payment_methods', 'cip_ajax_get_payment_methods');

function cip_ajax_get_payment_methods() {
    check_ajax_referer('cip_payment_direct', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Please login first']);
        return;
    }
    
    if (!class_exists('WooCommerce')) {
        wp_send_json_error(['message' => 'WooCommerce is not installed']);
        return;
    }
    
    // Get available payment gateways
    $gateways = WC()->payment_gateways->get_available_payment_gateways();
    $methods = [];
    
    if (empty($gateways)) {
        wp_send_json_error(['message' => 'No payment methods available. Please enable payment gateways in WooCommerce settings.']);
        return;
    }
    
    foreach ($gateways as $gateway_id => $gateway) {
        // Check if gateway is enabled and available
        if ($gateway->is_available() && $gateway->enabled === 'yes') {
            $methods[] = [
                'id' => $gateway_id,
                'title' => $gateway->get_title(),
                'description' => $gateway->get_description(),
                'icon' => $gateway->get_icon(),
                'method_title' => $gateway->get_method_title()
            ];
        }
    }
    
    if (empty($methods)) {
        wp_send_json_error(['message' => 'No payment methods are currently enabled. Please enable Razorpay or other payment gateways in WooCommerce > Settings > Payments.']);
        return;
    }
    
    wp_send_json_success(['methods' => $methods]);
}

/**
 * AJAX: Create Order and Get Payment Form
 * FIX #4: Added comprehensive validation
 */
add_action('wp_ajax_cip_create_payment_order', 'cip_ajax_create_payment_order');

function cip_ajax_create_payment_order() {
    // FIX #4: Better nonce and validation
    if (!check_ajax_referer('cip_payment_direct', 'nonce', false)) {
        wp_send_json_error(['message' => 'Security check failed. Please refresh the page.']);
        return;
    }
    
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Please login first']);
        return;
    }
    
    if (!class_exists('WooCommerce')) {
        wp_send_json_error(['message' => 'WooCommerce is not installed']);
        return;
    }
    
    // FIX #4: Validate inputs exist and are not null
    if (!isset($_POST['plan_index']) || !isset($_POST['payment_method'])) {
        error_log('CleanIndex Payment Error: Missing parameters');
        error_log('POST data: ' . print_r($_POST, true));
        wp_send_json_error(['message' => 'Missing required parameters']);
        return;
    }
    
    $plan_index = intval($_POST['plan_index']);
    $payment_method = sanitize_text_field($_POST['payment_method']);
    
    // FIX #4: Validate payment method is not empty or "null" string
    if (empty($payment_method) || $payment_method === 'null' || $payment_method === 'undefined') {
        error_log('CleanIndex Payment Error: Invalid payment method value: ' . $payment_method);
        wp_send_json_error(['message' => 'Please select a valid payment method']);
        return;
    }
    
    error_log("CleanIndex Payment: Processing - Method: {$payment_method}, Plan: {$plan_index}");
    
    // Get product
    $product_id = get_option('cip_woo_product_' . $plan_index);
    
    if (!$product_id) {
        wp_send_json_error(['message' => 'Product not found. Please contact support.']);
        return;
    }
    
    $product = wc_get_product($product_id);
    
    if (!$product) {
        wp_send_json_error(['message' => 'Invalid product. Please contact support.']);
        return;
    }
    
    // FIX #4: Better gateway validation
    $gateways = WC()->payment_gateways->get_available_payment_gateways();
    
    if (!isset($gateways[$payment_method])) {
        error_log("CleanIndex Payment Error: Gateway '{$payment_method}' not found in available gateways");
        error_log("Available gateways: " . print_r(array_keys($gateways), true));
        
        wp_send_json_error(['message' => "Payment method '{$payment_method}' is not available. Please try another method."]);
        return;
    }
    
    $gateway = $gateways[$payment_method];
    
    // Check if gateway is enabled
    if ($gateway->enabled !== 'yes') {
        wp_send_json_error(['message' => 'Selected payment method is disabled. Please contact support.']);
        return;
    }
    
    // Get current user
    $user = wp_get_current_user();
    
    // Get registration data
    global $wpdb;
    $table = $wpdb->prefix . 'company_registrations';
    $registration = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE email = %s",
        $user->user_email
    ), ARRAY_A);
    
    if (!$registration) {
        wp_send_json_error(['message' => 'Registration not found']);
        return;
    }
    
    try {
        // Clear cart first
        WC()->cart->empty_cart();
        
        // Add product to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, 1);
        
        if (!$cart_item_key) {
            throw new Exception('Failed to add product to cart');
        }
        
        // Create order programmatically
        $order = wc_create_order([
            'customer_id' => $user->ID,
            'customer_note' => 'CleanIndex Subscription',
            'created_via' => 'cleanindex'
        ]);
        
        if (is_wp_error($order)) {
            throw new Exception($order->get_error_message());
        }
        
        // Add product to order
        $order->add_product($product, 1);
        
        // Set billing details
        $order->set_billing_first_name($registration['employee_name']);
        $order->set_billing_email($registration['email']);
        $order->set_billing_company($registration['company_name']);
        $order->set_billing_country($registration['country']);
        
        // Calculate totals
        $order->calculate_totals();
        
        // Set payment method
        $order->set_payment_method($payment_method);
        $order->set_payment_method_title($gateway->get_title());
        
        // Add order meta
        $order->update_meta_data('_cip_plan_index', $plan_index);
        $order->update_meta_data('_cip_user_id', $user->ID);
        $order->update_meta_data('_cip_registration_id', $registration['id']);
        
        $order->save();
        
        // Set order as pending payment
        $order->update_status('pending', 'Order created via CleanIndex');
        
        // Process payment using the gateway
        $result = $gateway->process_payment($order->get_id());
        
        if (isset($result['result']) && $result['result'] === 'success') {
            // Clear cart after successful order creation
            WC()->cart->empty_cart();
            
            wp_send_json_success([
                'redirect' => $result['redirect'],
                'order_id' => $order->get_id()
            ]);
        } else {
            // Payment processing failed
            $order->update_status('failed', 'Payment processing failed');
            throw new Exception('Payment processing failed. Please try again.');
        }
        
    } catch (Exception $e) {
        error_log('CleanIndex Payment Error: ' . $e->getMessage());
        wp_send_json_error(['message' => $e->getMessage()]);
    }
}

/**
 * Handle Order Completion
 */
add_action('woocommerce_order_status_completed', 'cip_handle_woo_order_completed');
add_action('woocommerce_payment_complete', 'cip_handle_woo_order_completed');

function cip_handle_woo_order_completed($order_id) {
    $order = wc_get_order($order_id);
    
    if (!$order) {
        return;
    }
    
    // Check if it's a CleanIndex order
    $plan_index = $order->get_meta('_cip_plan_index');
    $user_id = $order->get_meta('_cip_user_id');
    $registration_id = $order->get_meta('_cip_registration_id');
    
    if ($plan_index === '' || !$user_id) {
        return;
    }
    
    // Check if already processed
    if ($order->get_meta('_cip_subscription_activated')) {
        return;
    }
    
    // Get plan details
    $pricing_plans = get_option('cip_pricing_plans', []);
    
    if (!isset($pricing_plans[$plan_index])) {
        return;
    }
    
    $plan = $pricing_plans[$plan_index];
    
    // Activate subscription
    $validity_years = get_option('cip_cert_validity_years', 1);
    $end_date = date('Y-m-d H:i:s', strtotime("+{$validity_years} year"));
    
    update_user_meta($user_id, 'cip_subscription_status', 'active');
    update_user_meta($user_id, 'cip_subscription_plan', $plan['name']);
    update_user_meta($user_id, 'cip_subscription_start', current_time('mysql'));
    update_user_meta($user_id, 'cip_subscription_end', $end_date);
    update_user_meta($user_id, 'cip_woo_order_id', $order_id);
    
    // Create subscription record if table exists
    global $wpdb;
    $subscription_table = $wpdb->prefix . 'cip_subscriptions';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$subscription_table'") === $subscription_table) {
        $wpdb->insert(
            $subscription_table,
            [
                'user_id' => $user_id,
                'company_id' => $registration_id,
                'plan_name' => $plan['name'],
                'plan_price' => $plan['price'],
                'currency' => isset($plan['currency']) ? $plan['currency'] : 'EUR',
                'status' => 'active',
                'payment_method' => $order->get_payment_method(),
                'transaction_id' => $order->get_transaction_id(),
                'end_date' => $end_date
            ]
        );
    }
    
    // Mark order as processed
    $order->update_meta_data('_cip_subscription_activated', true);
    $order->save();
    
    // Send notification
    if (function_exists('cip_create_notification')) {
        cip_create_notification(
            $user_id,
            'Subscription Activated',
            'Your ' . $plan['name'] . ' subscription is now active!',
            'success',
            home_url('/cleanindex/dashboard')
        );
    }
    
    // Auto-generate certificate if assessment complete
    if ($registration_id && class_exists('CIP_PDF_Generator')) {
        $table_assessments = $wpdb->prefix . 'company_assessments';
        $assessment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_assessments WHERE user_id = %d",
            $user_id
        ), ARRAY_A);
        
        if ($assessment && $assessment['progress'] >= 5 && !get_user_meta($user_id, 'cip_certificate_generated', true)) {
            try {
                $pdf = new CIP_PDF_Generator();
                $cert_url = $pdf->generate_certificate($user_id, $registration);
                
                if ($cert_url) {
                    update_user_meta($user_id, 'cip_certificate_generated', true);
                    update_user_meta($user_id, 'cip_certificate_url', $cert_url);
                    
                    if (function_exists('cip_create_notification')) {
                        cip_create_notification(
                            $user_id,
                            'Certificate Ready',
                            'Your ESG certificate has been generated and is ready for download!',
                            'success',
                            home_url('/cleanindex/certificate')
                        );
                    }
                }
            } catch (Exception $e) {
                error_log('CleanIndex: Certificate generation failed - ' . $e->getMessage());
            }
        }
    }
    
    error_log("CleanIndex: Subscription activated for order #{$order_id}, user #{$user_id}");
}

/**
 * Handle Order Cancellation
 */
add_action('woocommerce_order_status_cancelled', 'cip_handle_woo_order_cancelled');
add_action('woocommerce_order_status_failed', 'cip_handle_woo_order_cancelled');

function cip_handle_woo_order_cancelled($order_id) {
    $order = wc_get_order($order_id);
    
    if (!$order) {
        return;
    }
    
    $user_id = $order->get_meta('_cip_user_id');
    
    if ($user_id) {
        // Don't deactivate if subscription was already activated
        if (!$order->get_meta('_cip_subscription_activated')) {
            update_user_meta($user_id, 'cip_subscription_status', 'cancelled');
            
            if (function_exists('cip_create_notification')) {
                cip_create_notification(
                    $user_id,
                    'Payment Cancelled',
                    'Your payment was cancelled. Please try again if you wish to subscribe.',
                    'error',
                    home_url('/cleanindex/pricing')
                );
            }
        }
    }
}